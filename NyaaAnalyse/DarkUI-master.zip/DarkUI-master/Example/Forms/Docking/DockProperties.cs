﻿using DarkUI.Docking;

namespace Example
{
    public partial class DockProperties : DarkToolWindow
    {
        #region Constructor Region

        public DockProperties()
        {
            InitializeComponent();
        }

        #endregion
    }
}
