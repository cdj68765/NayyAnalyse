﻿namespace DarkUI.Forms
{
    public enum DarkDialogButton
    {
        Ok,
        Close,
        OkCancel,
        YesNo,
        YesNoCancel,
        AbortRetryIgnore,
        RetryCancel
    }
}
