﻿namespace DarkUI.Forms
{
    public enum DarkMessageBoxIcon
    {
        None,
        Information,
        Warning,
        Error
    }
}
