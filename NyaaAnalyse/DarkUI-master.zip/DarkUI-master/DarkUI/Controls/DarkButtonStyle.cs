﻿namespace DarkUI.Controls
{
    public enum DarkButtonStyle
    {
        Normal,
        Flat
    }
}
