﻿namespace DarkUI.Controls
{
    public enum DarkScrollOrientation
    {
        Vertical,
        Horizontal
    }
}
