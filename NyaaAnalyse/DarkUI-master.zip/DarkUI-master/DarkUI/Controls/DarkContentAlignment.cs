﻿namespace DarkUI.Controls
{
    public enum DarkContentAlignment
    {
        Center,
        Left,
        Right
    }
}
