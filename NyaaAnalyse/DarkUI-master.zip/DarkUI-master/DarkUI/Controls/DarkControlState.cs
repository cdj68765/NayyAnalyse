﻿namespace DarkUI.Controls
{
    public enum DarkControlState
    {
        Normal,
        Hover,
        Pressed
    }
}
