﻿namespace DarkUI.Docking
{
    public enum DarkSplitterType
    {
        Left,
        Right,
        Top,
        Bottom
    }
}
