﻿namespace DarkUI.Docking
{
    public enum DockInsertType
    {
        None,
        Before,
        After
    }
}
