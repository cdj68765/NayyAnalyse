﻿namespace DarkUI.Docking
{
    public enum DarkDockArea
    {
        None,
        Document,
        Left,
        Right,
        Bottom
    }
}
