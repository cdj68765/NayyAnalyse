﻿namespace CloudFlareCookies
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCfClearance = new System.Windows.Forms.TextBox();
            this.txtCfduid = new System.Windows.Forms.TextBox();
            this.txtUserAgent = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMain = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCfClearance
            // 
            this.txtCfClearance.Location = new System.Drawing.Point(86, 87);
            this.txtCfClearance.Name = "txtCfClearance";
            this.txtCfClearance.ReadOnly = true;
            this.txtCfClearance.Size = new System.Drawing.Size(361, 20);
            this.txtCfClearance.TabIndex = 13;
            // 
            // txtCfduid
            // 
            this.txtCfduid.Location = new System.Drawing.Point(86, 64);
            this.txtCfduid.Name = "txtCfduid";
            this.txtCfduid.ReadOnly = true;
            this.txtCfduid.Size = new System.Drawing.Size(361, 20);
            this.txtCfduid.TabIndex = 12;
            // 
            // txtUserAgent
            // 
            this.txtUserAgent.Location = new System.Drawing.Point(86, 41);
            this.txtUserAgent.Name = "txtUserAgent";
            this.txtUserAgent.ReadOnly = true;
            this.txtUserAgent.Size = new System.Drawing.Size(361, 20);
            this.txtUserAgent.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "cf_clearance:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "__cfduid:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "User Agent: ";
            // 
            // btnMain
            // 
            this.btnMain.Location = new System.Drawing.Point(12, 12);
            this.btnMain.Name = "btnMain";
            this.btnMain.Size = new System.Drawing.Size(435, 23);
            this.btnMain.TabIndex = 7;
            this.btnMain.Text = "Click me to get cookie info";
            this.btnMain.UseVisualStyleBackColor = true;
            this.btnMain.Click += new System.EventHandler(this.btnMain_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 114);
            this.Controls.Add(this.txtCfClearance);
            this.Controls.Add(this.txtCfduid);
            this.Controls.Add(this.txtUserAgent);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Poe.Trade cookie getter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCfClearance;
        private System.Windows.Forms.TextBox txtCfduid;
        private System.Windows.Forms.TextBox txtUserAgent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMain;
    }
}

